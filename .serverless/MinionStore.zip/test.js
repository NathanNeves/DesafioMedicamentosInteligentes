const axios = require('axios');
axios.post('https://ahx17z9jq8.execute-api.sa-east-1.amazonaws.com/dev/finalizarCompra',{ id: 8,email:"nathann-s@outlook.com",nome:'Nathan'}
).then(res=>{console.log(res.data);}).catch(err=>{
    console.log(err);
})